/*
* IntegralImage.java
*
* Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*
*/

package com.multithreading.cv.integral;

import image.AbstractImageProcessor;

import image.ImageProcessor;

import image.color.RGB;

import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.DataBufferInt;

/**
* Интегральное изображение.
*
* @author pavelvpster
*
*/
public final class IntegralImage extends AbstractImageProcessor {

	/**
	 * Конструктор по умолчанию.
	 *
	 */
	public IntegralImage() {

		isLazy = true;
	}

	// Параметризованные конструкторы

	public IntegralImage(BufferedImage sourceImage) {

		isLazy = true;

		setSourceImage(sourceImage);
	}


	/**
	 * @see ImageProcessor
	 *
	 */
	@Override
	public void setSourceImage(BufferedImage sourceImage) {

		this.sourceImage = sourceImage;

		// Рассчитываем размеры интегрального изображения

		width  = this.sourceImage.getWidth () + 1;
		height = this.sourceImage.getHeight() + 1;
	}


	/**
	 * Ширина интегрального изображения.
	 *
	 */
	public int width = 0;

	/**
	 * Высота интегрального изображения.
	 *
	 */
	public int height = 0;

	/**
	 * Интегральное изображение по интенсивностям точек.
	 *
	 */
	public double[][] sum = null;

	/**
	 * Интегральное изображение по квадратам интенсивностей точек.
	 *
	 */
	public double[][] square = null;

	/**
	 * Повернутое на 45 градусов интегральное изображение.
	 *
	 */
	public double[][] rotated = null;


	/**
	 * @see ImageProcessor
	 *
	 */
	@Override
	public void process() {

		if (sourceImage == null) {

			throw new RuntimeException("Source image undefined!");
		}

		// Получаем данные исходного изображения

		DataBuffer sourceBuffer = sourceImage.getRaster().getDataBuffer();

		byte[] sourceImageData = null; int[] sourceImageDataInt = null;

		if (sourceBuffer.getDataType() == DataBuffer.TYPE_BYTE) {

			sourceImageData = ((DataBufferByte)sourceBuffer).getData();

		} else

		if (sourceBuffer.getDataType() == DataBuffer.TYPE_INT) {

			sourceImageDataInt = ((DataBufferInt)sourceBuffer).getData();

		} else {

			throw new RuntimeException("Unsupported image type!");
		}

		// Строим интегральные изображения

		sum = new double[ width ][ height ];

		square = new double[ width ][ height ];

		rotated = new double[ width ][ height ];

		for (int y = 1, i = 0; y < height; y ++) {

			double s = 0.0, q = 0.0;

			for (int x = 1; x < width; x ++) {

				// Получаем компоненты цвета RGB

				int r, g, b;

				switch (sourceImage.getType()) {

					case BufferedImage.TYPE_INT_RGB:

						int c = sourceImageDataInt[ i ++ ];

						r = (c & 0x00FF0000) >> 16;
						g = (c & 0x0000FF00) >> 8;
						b = (c & 0x000000FF);

						break;

					case BufferedImage.TYPE_3BYTE_BGR:

						b = sourceImageData[ i ++ ] & 0xFF;
						g = sourceImageData[ i ++ ] & 0xFF;
						r = sourceImageData[ i ++ ] & 0xFF;

						break;

					case BufferedImage.TYPE_BYTE_GRAY:

						r = g = b = sourceImageData[ i ++ ] & 0xFF;

						break;

					default:

						throw new RuntimeException("Unsupported image type!");
				}

				// Расчитываем интенсивность точки

				double I = 0.299 * r + 0.587 * g + 0.114 * b;

				// Копим интенсивности точек

				s += I;

				sum[x][y] = sum[x][y - 1] + s;

				// Копим квадраты интенсивностей точек

				q += I * I;

				square[x][y] = square[x][y - 1] + q;

				// Расчитываем интенсивности точек повернутого изображения

				rotated[x][y] = I;

				if (x > 1) {

					rotated[x][y] += rotated[x - 1][y - 1] +
						rotated[x - 1][y] - rotated[x - 2][y - 1];
				}
			}
		}

		// Второй проход по повернутому интегральному изображению

		for (int y = height - 2; y > -1; y --) {

			for (int x = width - 1; x > 1; x --) {

				rotated[x][y] += rotated[x - 1][y + 1] - rotated[x - 2][y];
			}
		}
	}


	/**
	 * @see AbstractImageProcessor
	 *
	 */
	@Override
	public void render() {

		processedImage = null; if (sum == null) return ;

		// Считаем диапазон изменения значений

		double minSum = Double.MAX_VALUE;
		double maxSum = Double.MIN_VALUE;

		for (int y = 0; y < height; y ++) {

			for (int x = 0; x < width; x ++) {

				if (sum[x][y] < minSum) minSum = sum[x][y];
				if (sum[x][y] > maxSum) maxSum = sum[x][y];
			}
		}

		// Строим изображение выполняя ремапинг значений

		processedImage = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);

		for (int y = 0; y < height; y ++) {

			for (int x = 0; x < width; x ++) {

				int i = (int)(255.0 * (sum[x][y] - minSum) / (maxSum - minSum));

				RGB t = new RGB(i);

				t.set(processedImage, x, y);
			}
		}
	}

}

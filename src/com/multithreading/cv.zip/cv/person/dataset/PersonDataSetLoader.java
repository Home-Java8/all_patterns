/*
 * PersonDataSetLoader.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package com.multithreading.cv.person.dataset;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

/**
 * Этот класс читает данные пользователей.
 * 
 * @author pavelvpster
 * 
 */
public final class PersonDataSetLoader {

	private static final Logger LOG = Logger.getLogger(PersonDataSetLoader.class);


	/**
	 * Этот метод читает данные пользователей.
	 *
	 * @param filename имя файла.
	 * 
	 * @return PersonDataSet набор данных пользователей.
	 *
	 */
	public static PersonDataSet load(String filename) {
		
		LOG.debug("Loading person data set...");

		// Читаем набор данных пользователей
		
		PersonDataSet personDataSet = null;

		try {

			JAXBContext context = JAXBContext.newInstance(PersonDataSet.class);

			Unmarshaller unmarshaller = context.createUnmarshaller();

			personDataSet = (PersonDataSet)unmarshaller.unmarshal(new FileInputStream(filename));

		} catch (JAXBException | FileNotFoundException E) {

			LOG.error(E);
		}

		if (personDataSet == null) return null;
		
		// Добавляем путь к именам файлов

		File f = new File(filename);

		final String path = f.getParent();

		for (PersonData x : personDataSet.persons) {
			
			for (int i = 0; i < x.images.size(); i ++) {
				
				x.images.set(i, path + x.images.get(i));
			}
		}
		
		LOG.debug("Done. " + personDataSet.persons.size() + " persons in data set.");
		
		return personDataSet;
	}
	
}

/*
 * PersonCollection.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Коллекция пользователей.
 * 
 * @author pavelvpster
 * 
 */
@XmlRootElement
public final class PersonCollection {
	
	/**
	 * Конструктор по умолчанию.
	 * 
	 */
	public PersonCollection() {
	}


	/**
	 * Пользователи.
	 * 
	 */
	public ArrayList <Person> persons = new ArrayList <> ();
	
	/**
	 * Порог.
	 * 
	 * Используется при опознавании.
	 * 
	 */
	public double threshold = Double.POSITIVE_INFINITY;
	
	
	/**
	 * Этот метод возвращает пользователя с указанным идентификатором.
	 * 
	 * @param id идентификатор пользователя.
	 * 
	 * @return Person пользователь.
	 * 
	 */
	public Person getPersonById(String id) {
	
		for (Person person : persons) {
			
			if (person.id.equals(id)) return person;
		}
		
		return null;
	}
	
}

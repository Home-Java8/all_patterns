/*
 * PersonCollectionHelper.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person;

import cv.face.detector.Face;
import cv.face.detector.FaceDetector;

import image.util.ImageLoader;

import java.awt.image.BufferedImage;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * Этот класс содержит вспомогательные методы для работы с коллекцией пользователей.
 * 
 * @author pavelvpster
 * 
 */
public class PersonCollectionHelper {
	
	private static final Logger LOG = Logger.getLogger(PersonCollectionHelper.class);
	
	
	/**
	 * Этот метод добавляет пользователя с использованием наблюдений лица.
	 * 
	 * @param personCollection коллекция пользователей,
	 * 
	 * @param id идентификатор пользователя,
	 * 
	 * @param observations наблюдения лица.
	 * 
	 */
	public static void addPersonWithFaceObservations(PersonCollection personCollection, String id, List <Face> observations) {

		LOG.debug("Adding person " + id + "...");
		
		Person person = new Person(id);
		
		person.faceStatistics.update(observations);
		
		personCollection.persons.add(person);
		
		LOG.debug("Done.");
	}

	/**
	 * Этот метод добавляет пользователя с использованием изображений лица.
	 * 
	 * @param personCollection коллекция пользователей,
	 * 
	 * @param id идентификатор пользователя,
	 * 
	 * @param faceImages изображения лица.
	 * 
	 */
	public static void addPersonWithFaceImages(PersonCollection personCollection, String id, List <BufferedImage> faceImages) {

		LOG.debug("Add person using face images...");
		
		// Создаем детектор лиц
		
		FaceDetector faceDetector = new FaceDetector();
		
		// Обнаруживаем лица

		ArrayList <Face> faces = new ArrayList <> ();

		int i = 1;
		
		for (BufferedImage image : faceImages) {
			
			LOG.debug("Detecting face on image " + (i++) );
			
			faceDetector.setSourceImage(image);
			
			faceDetector.process();
			
			// Нас интересует лицо, обнаруженное с наибольшей достоверностью
			
			Face mainFace = faceDetector.getMainFace();
			
			if (mainFace == null) {
				
				LOG.error("Face not detected!");
				
				continue ;
			}
			
			LOG.debug("Done.");
			
			faces.add(mainFace);
		}
		
		LOG.debug(faces.size() + " faces detected.");
		
		// Добавляем пользователя
		
		addPersonWithFaceObservations(personCollection, id, faces);
		
		LOG.debug("Done.");
	}
	
	/**
	 * Этот метод добавляет пользователя с использованием изображений лица из файлов.
	 * 
	 * @param personCollection коллекция пользователей,
	 * 
	 * @param id идентификатор пользователя,
	 * 
	 * @param faceImageFilenames имена файлов изображений лица.
	 * 
	 */
	public static void addPersonWithFaceImageFiles(PersonCollection personCollection, String id, List <String> faceImageFilenames) {
		
		LOG.debug("Add person using face image files...");
		
		// Загружаем изображения
		
		ArrayList <BufferedImage> faceImages = new ArrayList <> ();
		
		for (String filename : faceImageFilenames) {
			
			LOG.debug("Loading image [" + filename + "]...");
			
			BufferedImage faceImage = ImageLoader.load(filename);
			
			if (faceImage == null) {
				
				LOG.error("Error loading image [" + filename + "]!");
				
				continue ;
			}
			
			LOG.debug("Done.");
			
			faceImages.add(faceImage);
		}
		
		LOG.debug(faceImages.size() + " images loaded.");
		
		// Добавляем пользователя
		
		addPersonWithFaceImages(personCollection, id, faceImages);
		
		LOG.debug("Done.");
	}
	
}

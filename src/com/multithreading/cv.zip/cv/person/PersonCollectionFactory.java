/*
 * PersonCollectionFactory.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person;

import math.Vector;

import org.apache.log4j.Logger;

import cv.person.dataset.PersonData;
import cv.person.dataset.PersonDataSet;

/**
 * Создание коллекции пользователей.
 * 
 * @author pavelvpster
 * 
 */
public final class PersonCollectionFactory {
	
	private static final Logger LOG = Logger.getLogger(PersonCollectionFactory.class);
	
	
	/**
	 * Этот метод создает коллекцию пользователей.
	 * 
	 * @return new PersonCollection новая коллекция пользователей.
	 * 
	 */
	public static PersonCollection createPersonCollection() {
		
		return new PersonCollection();
	}
	
	/**
	 * Этот метод создает коллекцию пользователей с использованием набора данных пользователей.
	 * 
	 * @param personDataSet набор данных пользователей.
	 * 
	 * @return new PersonCollection новая коллекция пользователей.
	 * 
	 */
	public static PersonCollection createPersonCollection(PersonDataSet personDataSet) {
		
		LOG.debug("Creating person collection using person data set...");
		
		PersonCollection personCollection = new PersonCollection();
		
		// Добавляем пользователей
		
		for (PersonData personData : personDataSet.persons) {
			
			PersonCollectionHelper.
					
				addPersonWithFaceImageFiles(personCollection, personData.id, personData.images);
		}
		
		LOG.debug(personCollection.persons.size() + " persons added.");
		
		LOG.debug("Calculate threshold...");
		
		// Вычисляем порог, сравнивая пользователей
		
		double minD = Double.MAX_VALUE;
		double maxD = Double.MIN_VALUE;
			
		for (Person person : personCollection.persons) {
			
			final Vector a = new Vector(person.faceStatistics.mean);
			
			for (Person x : personCollection.persons) {

				if (x == person) continue ;
				
				final Vector b = new Vector(x.faceStatistics.mean);
				
				final double d = b.calculateDistanceTo(a);
				
				LOG.debug("Match person " + person.id + " to person " + x.id + ": distance = " + d);
				
				if (d < minD) {
					
					minD = d;
				}
				
				if (d > maxD) {
					
					maxD = d;
				}
			}
		}
		
		LOG.debug("Min distance = " + minD);
		LOG.debug("Max distance = " + maxD);

		// Рассчитываем порог
		
		personCollection.threshold = maxD - (maxD - minD) * ALPHA;
		
		LOG.debug("Threshold = " + personCollection.threshold);
		
		LOG.debug("Done.");
		
		return personCollection;
	}
	
	
	/**
	 * Соотношение между FAR и FRR.
	 * 
	 * Диапазон изменения значения: [0.0 ... 1.0]
	 * 
	 * Чем больше алфа, тем точнее опознавание (меньше FAR), но и больше отказов (больше FRR).
	 * 
	 */
	public static final double ALPHA = 0.75;
	
}

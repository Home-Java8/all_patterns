/*
 * PersonCollectionSaver.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;

/**
 * Этот класс сохраняет коллекцию пользователей в XML файл.
 * 
 * @author pavelvpster
 * 
 */
public final class PersonCollectionSaver {
	
	private static final Logger LOG = Logger.getLogger(PersonCollectionSaver.class);
	
	
	/**
	 * Этот метод сохраняет указанную коллекцию пользователей в файл.
	 * 
	 * @param personCollection коллекция пользователей,
	 * 
	 * @param filename имя файла.
	 * 
	 */
	public static void save(PersonCollection personCollection, String filename) {
		
		LOG.debug("Saving person collection...");
		
		try {
			
			JAXBContext context = JAXBContext.newInstance(PersonCollection.class);

			Marshaller marshaller = context.createMarshaller();
			
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshaller.marshal(personCollection, new FileOutputStream(filename));
			
		} catch (JAXBException | FileNotFoundException E) {
			
			LOG.error(E);
		}
		
		LOG.debug("Done.");
	}
	
}

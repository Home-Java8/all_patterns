/*
 * PersonRecognizerProcessor.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person.recognizer;

import cv.face.detector.Face;
import cv.face.detector.FaceDetector;

import image.AbstractImageProcessor;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

import java.util.ArrayList;

import cv.person.PersonCollection;

/**
 * Опознаватель пользователей.
 * 
 * @author pavelvpster
 * 
 */
public class PersonRecognizerProcessor extends AbstractImageProcessor {
	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param personCollection коллекция пользователей.
	 * 
	 */
	public PersonRecognizerProcessor(PersonCollection personCollection) {
		
		isLazy = true;
		
		faceDetector = new FaceDetector();
		
		personRecognizer = new PersonRecognizerEx(personCollection);
	}
	
	// Параметризованные конструкторы
	
	public PersonRecognizerProcessor(PersonCollection personCollection, BufferedImage sourceImage) {
		
		isLazy = true;
		
		faceDetector = new FaceDetector(sourceImage);
		
		personRecognizer = new PersonRecognizerEx(personCollection);
	}
	
	
	/**
	 * @see ImageProcessor
	 * 
	 */
	@Override
	public void setSourceImage(BufferedImage sourceImage) {
		
		// Передаем изображение детектору лиц

		faceDetector.setSourceImage(sourceImage);
	}
	
	/**
	 * @see ImageProcessor
	 * 
	 */
	@Override
	public BufferedImage getSourceImage() {
		
		return faceDetector.getSourceImage();
	}
	
	
	/**
	 * Детектор лиц.
	 * 
	 */
	private final FaceDetector faceDetector;
	
	/**
	 * Опознаватель пользователей.
	 * 
	 */
	private final PersonRecognizerEx personRecognizer;
	
	
	/**
	 * Результаты опознавания.
	 * 
	 */
	public ArrayList <PersonRecognitionResult> recognitionResults = new ArrayList <> ();
	

	@Override
	public void process() {
		
		// Cleanup
		
		recognitionResults.clear();
		
		// Обнаруживаем лица
		
		faceDetector.process();
		
		// Пробуем их опознать
		
		for (Face face : faceDetector.faces) {
			
			// Опознаем лицо
			
			personRecognizer.face = face;
			
			personRecognizer.identify();
			
			if (personRecognizer.recognitionResults.isEmpty()) continue ;
			
			// Если все ОК, сохраняем
			
			recognitionResults.add(personRecognizer.recognitionResults.get(0));
		}
	}
	
	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
			(getSourceImage().getWidth(), getSourceImage().getHeight(), getSourceImage().getType());
		
		// Получаем графический контекст

		Graphics2D G = processedImage.createGraphics();

		// Размещаем исходное изображение

		G.drawImage(getSourceImage(), 0, 0, null);
		
		// Отображаем обнаруженные лица
		
		new PersonRecognizerRender(recognitionResults).render(G);

		G.dispose();
	}
	
}

/*
 * PersonRecognizerEx.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person.recognizer;

import cv.face.detector.Face;

import cv.face.matcher.FaceMatcher;

import java.util.ArrayList;
import java.util.Collections;

import org.apache.log4j.Logger;

import cv.person.Person;
import cv.person.PersonCollection;

/**
 * Опознаватель пользователей.
 * 
 * @author pavelvpster
 * 
 */
public final class PersonRecognizerEx {
	
	private static final Logger LOG = Logger.getLogger(PersonRecognizerEx.class);

	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param personCollection коллекция пользователей.
	 * 
	 */
	public PersonRecognizerEx(PersonCollection personCollection) {
		
		this.personCollection = personCollection;
	}
	
	// Параметризованные конструкторы
	
	public PersonRecognizerEx(PersonCollection personCollection, Face face) {
		
		this.personCollection = personCollection; this.face = face;
	}
	
	public PersonRecognizerEx(PersonCollection personCollection, Face face, int rank) {
		
		this.personCollection = personCollection; this.face = face; this.rank = rank;
	}
	
	public PersonRecognizerEx(PersonCollection personCollection, int rank) {
		
		this.personCollection = personCollection; this.rank = rank;
	}
	

	/**
	 * Коллекция пользователей.
	 * 
	 */
	public final PersonCollection personCollection;

	/**
	 * Ранг.
	 * 
	 * Определяет наибольшее количество сохраняемых результатов.
	 * 
	 */
	public int rank = 3;

	
	/**
	 * Опознаваемое лицо.
	 * 
	 */
	public Face face = null;

	/**
	 * Результаты опознавания.
	 * 
	 */
	public ArrayList <PersonRecognitionResult> recognitionResults = new ArrayList <> ();
	
	
	/**
	 * Этот метод возвращает наиболее достоверный результат опознавания.
	 * 
	 * @return Person пользователь.
	 * 
	 * Если опознавание не удалось, метод возвращает null.
	 * 
	 */
	public Person getMainResult() {
		
		if (recognitionResults.isEmpty()) return null;
		
		// Наибольшая достоверность у первого результата
		
		return recognitionResults.get(0).person;
	}
	
	
	/**
	 * Этот метод выполняет опознавание.
	 * 
	 */
	public void identify() {
		
		LOG.debug("Try to identify person by face... Rank = " + rank);
		
		// Cleanup
		
		recognitionResults.clear();
		
		// Preconditions
		
		if (face == null) {

			LOG.error("Face undefined!"); return ;
		}
		
		// Сравниваем
		
		ArrayList <PersonRecognitionResult> r = new ArrayList <> ();
		
		for (Person person : personCollection.persons) {
			
			final double d = FaceMatcher.match(face, person.faceStatistics);
			
			LOG.debug("Match to person " + person.id + ": distance = " + d);

			if (d < personCollection.threshold) {
				
				r.add( new PersonRecognitionResult(face, person, d) );
			}
		}
		
		// В редких редких случаях :) все расстояния равны 0.0 и опознавание невозможно

		boolean f = true;
		
		for (PersonRecognitionResult x : r) {
			
			if (x.d != 0.0) {
				
				f = false; break;
			}
		}
		
		if (f) {
			
			LOG.debug("Cancel. All distances are 0.0");
			
			return ;
		}
		
		// Сортируем результаты
		
		Collections.sort(r);
		
		// Сохраняем заданное количество результатов
		
		recognitionResults.addAll( r.subList(0, Math.min(rank, r.size())) );
		
		
		LOG.debug("Done. " + (recognitionResults.isEmpty() ? "Person not recognized." : 
				
			recognitionResults.size() + " results saved. Most probable " + recognitionResults.get(0).person.id + "."));
		
		
		// Рассчитываем достоверность результатов
		
		double s = 0.0;

		for (PersonRecognitionResult x : recognitionResults) {

			s += x.d;
		}

		for (PersonRecognitionResult x : recognitionResults) {

			x.p = 1.0 - x.d / s;
		}
		
		
		LOG.debug("P = " + (recognitionResults.isEmpty() ? "Unknown." : recognitionResults.get(0).p));
	}
	
}

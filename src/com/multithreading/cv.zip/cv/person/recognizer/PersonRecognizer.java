/*
 * PersonRecognizer.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person.recognizer;

import cv.face.detector.Face;

import cv.face.matcher.FaceMatcher;

import org.apache.log4j.Logger;

import cv.person.Person;
import cv.person.PersonCollection;

/**
 * Опознаватель пользователей.
 * 
 * @author pavelvpster
 * 
 */
public final class PersonRecognizer {
	
	private static final Logger LOG = Logger.getLogger(PersonRecognizer.class);
	
	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param personCollection коллекция пользователей.
	 * 
	 */
	public PersonRecognizer(PersonCollection personCollection) {
		
		this.personCollection = personCollection;
	}
	
	// Параметризованные конструкторы
	
	public PersonRecognizer(PersonCollection personCollection, Face face) {
		
		this.personCollection = personCollection; this.face = face;
	}
	
	
	/**
	 * Коллекция пользователей.
	 * 
	 */
	public final PersonCollection personCollection;

	
	/**
	 * Опознаваемое лицо.
	 * 
	 */
	public Face face = null;

	/**
	 * Результат опознавания.
	 * 
	 */
	public PersonRecognitionResult recognitionResult = null;
	
	
	/**
	 * Этот метод возвращает результат опознавания.
	 * 
	 * @return Person пользователь.
	 * 
	 * Если опознавание не удалось, метод возвращает null.
	 * 
	 */
	public Person getResult() {
		
		if (recognitionResult == null) return null;
		
		return recognitionResult.person;
	}
	
	
	/**
	 * Этот метод выполняет опознавание.
	 * 
	 */
	public void identify() {
		
		LOG.debug("Try to identify person by face...");
		
		// Cleanup
		
		recognitionResult = null;
		
		// Preconditions
		
		if (face == null) {

			LOG.error("Face undefined!"); return ;
		}
		
		// Сравниваем
		
		Person r = null;
		
		double minD = Double.MAX_VALUE;
		
		for (Person person : personCollection.persons) {
			
			final double d = FaceMatcher.match(face, person.faceStatistics);
			
			LOG.debug("Match to person " + person.id + ": distance = " + d);
			
			if (d < personCollection.threshold) {
				
				if (d < minD) {

					minD = d; r = person;
				}
			}
		}
		
		
		LOG.debug("Done. " + (r == null ? "Person not recognized." : "Person recognized as " + r.id + "."));
		
		
		// Сохраняем результат
		
		if (r != null) {
			
			recognitionResult = new PersonRecognitionResult(face, r, minD);
		}
	}

}

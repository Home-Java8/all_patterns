/*
 * PersonRecognitionResult.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person.recognizer;

import cv.face.detector.Face;

import cv.person.Person;

/**
 * Результат опознавания пользователя.
 * 
 * @author pavelvpster
 * 
 */
public final class PersonRecognitionResult implements Comparable <PersonRecognitionResult> {
	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param face опознаваемое лицо,
	 * 
	 * @param person сопоставленный пользователь,
	 * 
	 * @param d "расстояние" между ними.
	 * 
	 */
	public PersonRecognitionResult(Face face, Person person, double d) {
		
		this.face = face; this.person = person; this.d = d;
	}
	
	
	/**
	 * Опознаваемое лицо.
	 * 
	 */
	public final Face face;
	
	/**
	 * Сопоставленный пользователь.
	 * 
	 */
	public final Person person;

	/**
	 * Расстояние.
	 * 
	 */
	public final double d;
	
	/**
	 * Вероятность.
	 * 
	 */
	public double p = 0.0;

	
	@Override
	public int compareTo(PersonRecognitionResult o) {
		
		return new Double(d).compareTo(o.d);
	}
	
}

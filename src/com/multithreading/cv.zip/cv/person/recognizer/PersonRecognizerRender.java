/*
 * PersonRecognizerRender.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.person.recognizer;

import common.ui.view.Render;

import cv.ui.RenderingParameters;

import geom.Rectangle;

import java.awt.Graphics2D;

import java.util.ArrayList;

/**
 * Рендер результатов опознавания.
 * 
 * @author pavelvpster
 * 
 */
public class PersonRecognizerRender implements Render {

	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param recognitionResults результаты опознавания.
	 * 
	 */
	public PersonRecognizerRender(ArrayList <PersonRecognitionResult> recognitionResults) {
		
		this.recognitionResults = recognitionResults;
	}
	
	
	/**
	 * Результаты опознавания для рендеринга.
	 * 
	 */
	public final ArrayList <PersonRecognitionResult> recognitionResults;
	
	
	@Override
	public void render(Graphics2D G) {
		
		for (PersonRecognitionResult x : recognitionResults) drawRecognitionResult(x, G);
	}
	
	
	/**
	 * Этот метод выполняет рендеринг указанного результата опознавания.
	 * 
	 */
	public static void drawRecognitionResult(PersonRecognitionResult result, Graphics2D G) {
		
		// Цвет
		
		G.setColor(RenderingParameters.RECOGNIZED_FACE_COLOR);
		
		// Тип линии
		
		G.setStroke(RenderingParameters.RECOGNIZED_FACE_STROKE);

		// Прямоугольник
		
		final Rectangle r = result.face.haarObject.rectangle;
		
		G.drawRect(r.x, r.y, r.width, r.height);
		
		// Описание
		
		String t = String.format("Person: %s (P = %.2f)", result.person.id, result.p);
		
		G.drawString(t, r.x, r.y - 5);
	}
	
}

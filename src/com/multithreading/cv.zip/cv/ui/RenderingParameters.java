/*
 * RenderingParameters.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Stroke;

/**
 * Параметры рендеринга.
 * 
 * @author pavelvpster
 * 
 */
public class RenderingParameters {
	
	//
	// Разные объекты
	//
	
	
	/**
	 * Движение.
	 * 
	 */
	public static final Color MOTION_COLOR = new Color(0xFF, 0, 0);
	
	
	/**
	 * Цвет.
	 * 
	 */
	public static final Color OBJECT_COLOR = new Color(0xCC, 0x66, 0x00);

	/**
	 * Тип линии.
	 * 
	 */
	public static final Stroke OBJECT_STROKE = new BasicStroke(2.0f);

	
	//
	// Face
	//
	
	
	/**
	 * Цвет.
	 * 
	 */
	public static final Color FACE_COLOR = new Color(0x00, 0x66, 0xCC);

	/**
	 * Тип линии.
	 * 
	 */
	public static final Stroke FACE_STROKE = new BasicStroke(2.0f);

	
	//
	// Recognized face
	//
	
	
	/**
	 * Цвет.
	 * 
	 */
	public static final Color RECOGNIZED_FACE_COLOR = new Color(0x66, 0xCC, 0x00);

	/**
	 * Тип линии.
	 * 
	 */
	public static final Stroke RECOGNIZED_FACE_STROKE = new BasicStroke(2.0f);

}

/*
 * ColorPointDetector.java
 *
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package com.multithreading.cv.color.point;

import geom.Point2D;

import image.AbstractImageProcessor;

import image.ImageProcessor;

import image.color.RGB;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

import java.util.ArrayList;

/**
 * Обнаружение точек по цвету.
 *
 * @author pavelvpster
 * 
 */
public final class ColorPointDetector extends AbstractImageProcessor {

	/**
	 * Конструктор по умолчанию.
	 *
	 */
	public ColorPointDetector() {
		
		isLazy = true;
	}

	// Параметризованные конструкторы

	public ColorPointDetector(BufferedImage sourceImage) {
		
		isLazy = true;
		
		this.sourceImage = sourceImage;
	}

	public ColorPointDetector(BufferedImage sourceImage, RGB target, double threshold) {
		
		isLazy = true;
		
		this.sourceImage = sourceImage;

		this.target = target; this.threshold = threshold;
	}

	public ColorPointDetector(RGB target, double threshold) {
		
		isLazy = true;
		
		this.target = target; this.threshold = threshold;
	}


	/**
	 * Искомый цвет.
	 * 
	 */
	public RGB target = null;

	/**
	 * Порог разницы цветов.
	 * 
	 */
	public double threshold = 0.0;

	/**
	 * Обнаруженные точки.
	 * 
	 */
	public ArrayList <Point2D> points = new ArrayList <> ();

	
	/**
	 * @see ImageProcessor
	 *
	 */
	@Override
	public void process() {

		if (sourceImage == null) {

			throw new RuntimeException("Source image undefined!");
		}
		
		// Без искомого цвета делать нечего
		
		if (target == null) {
			
			throw new RuntimeException("Bad parameters!");
		}
		
		// Color Point Detection

		points.clear();
		
		for (int y = 0; y < sourceImage.getHeight(); y ++) {
			
			for (int x = 0; x < sourceImage.getWidth(); x ++) {

				RGB a = RGB.get(sourceImage, x, y);
				
				// Вычисляем разницу с искомым цветом
				
				double d = a.calculateDistance(target);
				
				// Проверяем порог

				if (d > threshold) continue ;
				
				// OK

				points.add(new Point2D(x, y));
			}
		}
	}
	
	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
				(sourceImage.getWidth(), sourceImage.getHeight(), sourceImage.getType());

		// Получаем графический контекст

		Graphics2D G = processedImage.createGraphics();

		// Размещаем исходное изображение

		G.drawImage(sourceImage, 0, 0, null);
		
		// Рисуем точки
		
		for (Point2D p : points) {
			
			target.set(processedImage, p.x, p.y);
		}
		
		G.dispose();
	}

}

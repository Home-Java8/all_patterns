/*
 * ColorPointDetectorEx.java
 *
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package com.multithreading.cv.color.point;

import geom.Point2D;

import image.AbstractImageProcessor;

import image.ImageProcessor;

import image.color.RGB;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Обнаружение точек по цвету.
 *
 * Эта расширенная версия поддерживает множество искомых цветов.
 *
 * @author pavelvpster
 * 
 */
public final class ColorPointDetectorEx extends AbstractImageProcessor {

	/**
	 * Конструктор по умолчанию.
	 *
	 */
	public ColorPointDetectorEx() {
		
		isLazy = true;
	}

	// Параметризованные конструкторы

	public ColorPointDetectorEx(BufferedImage sourceImage) {
		
		isLazy = true;
		
		this.sourceImage = sourceImage;
	}

	public ColorPointDetectorEx(BufferedImage sourceImage, List <RGB> target, double threshold) {
		
		isLazy = true;
		
		this.sourceImage = sourceImage;

		this.target.addAll(target); this.threshold = threshold;
	}

	public ColorPointDetectorEx(List <RGB> target, double threshold) {
		
		isLazy = true;
		
		this.target.addAll(target); this.threshold = threshold;
	}


	/**
	 * Искомый цвет.
	 * 
	 */
	public ArrayList <RGB> target = null;

	/**
	 * Порог разницы цветов.
	 * 
	 */
	public double threshold = 0.0;

	/**
	 * Обнаруженные точки.
	 * 
	 */
	public Map <RGB, ArrayList <Point2D>> points = new HashMap <> ();

	
	/**
	 * @see ImageProcessor
	 *
	 */
	@Override
	public void process() {

		if (sourceImage == null) {

			throw new RuntimeException("Source image undefined!");
		}
		
		// Без искомого цвета делать нечего
		
		if (target == null) {
			
			throw new RuntimeException("Bad parameters!");
		}
		
		// Color Point Detection

		points.clear();
		
		for (int y = 0; y < sourceImage.getHeight(); y ++) {
			
			for (int x = 0; x < sourceImage.getWidth(); x ++) {

				final RGB a = RGB.get(sourceImage, x, y);
				
				// Вычисляем разницу с искомыми цветами
				
				RGB r = null;
				
				double minD = Double.MAX_VALUE;
				
				for (RGB t : target) {
					
					final double d = a.calculateDistance(t);
					
					if (d < minD) {
						
						minD = d; r = t;
					}
				}
				
				// Проверяем порог

				if (minD > threshold) continue ;
				
				// OK

				if (points.containsKey(r)) {

					// Добавляем точку к массиву точек из карты
					
					points.get(r).add(new Point2D(x, y));
					
				} else {
					
					// Создаем новый массив точек и добавляем в карту
					
					ArrayList <Point2D> t = new ArrayList <> ();
					
					t.add(new Point2D(x, y));
					
					points.put(r, t);
				}
			}
		}
	}
	
	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
				(sourceImage.getWidth(), sourceImage.getHeight(), sourceImage.getType());

		// Получаем графический контекст

		Graphics2D G = processedImage.createGraphics();

		// Размещаем исходное изображение

		G.drawImage(sourceImage, 0, 0, null);
		
		// Рисуем точки

		for (RGB c : points.keySet()) {
			
			for (Point2D p : points.get(c)) {

				c.set(processedImage, p.x, p.y);
			}
		}
		
		G.dispose();
	}
	
}

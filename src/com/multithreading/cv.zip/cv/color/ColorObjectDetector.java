/*
 * ColorObjectDetector.java
 *
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package com.multithreading.cv.color;

import image.AbstractImageProcessor;

import image.color.RGB;

import java.awt.image.BufferedImage;

import ml.clustering.kmeans.Cluster;
import ml.clustering.kmeans.KMeansClusterer;

import java.awt.Graphics2D;

import java.util.ArrayList;

/**
 * Обнаружение объекта по цвету.
 * 
 * @author pavelvpster
 * 
 */
public final class ColorObjectDetector extends AbstractImageProcessor {

	/**
	 * Конструктор по умолчанию.
	 *
	 */
	public ColorObjectDetector() {
		
		isLazy = true;
	}

	// Параметризованные конструкторы

	public ColorObjectDetector(BufferedImage sourceImage) {
		
		isLazy = true;
		
		this.sourceImage = sourceImage;
	}

	public ColorObjectDetector(BufferedImage sourceImage, RGB target, double threshold) {
		
		isLazy = true;
		
		this.sourceImage = sourceImage;
		
		this.target = target; this.threshold = threshold;
	}

	public ColorObjectDetector(RGB target, double threshold) {

		isLazy = true;
		
		this.target = target; this.threshold = threshold;
	}


	/**
	 * Искомый цвет.
	 * 
	 */
	public RGB target = null;

	/**
	 * Порог разницы цветов.
	 * 
	 */
	public double threshold = 0.0;
	
	/**
	 * Предполагаемое количество возможных положений объекта.
	 * 
	 */
	public int k = 32;
	
	
	/**
	 * Обнаруженные объекты.
	 * 
	 */
	public ArrayList <ColorObject> objects = new ArrayList <> ();

	
	/**
	 * Этот метод возвращает объект с наибольшим количеством точек.
	 * 
	 * @return ColorObject объект.
	 * 
	 * Если объекты не обнаружены, метод возвращает null.
	 * 
	 */
	public ColorObject getMainObject() {
		
		ColorObject r = null;
		
		double maxN = 0;
		
		for (ColorObject object : objects) {
			
			if (object.n > maxN) {
				
				maxN = object.n; r = object;
			}
		}
		
		return r;
	}

	
	/**
	 * @see IImageProcessor
	 *
	 */
	@Override
	public void process() {

		if (sourceImage == null) {

			throw new RuntimeException("Source image undefined!");
		}
		
		// Без искомого цвета делать нечего
		
		if (target == null) {
			
			throw new RuntimeException("Bad parameters!");
		}
		
		// Создаем кластеризатор
		
		KMeansClusterer kmeans = new KMeansClusterer(k);

		// Color Point Detection

		for (int y = 0; y < sourceImage.getHeight(); y ++) {
			
			for (int x = 0; x < sourceImage.getWidth(); x ++) {

				final RGB a = RGB.get(sourceImage, x, y);
				
				// Вычисляем разницу с искомым цветом
				
				final double d = a.calculateDistance(target);
				
				// Проверяем порог

				if (d > threshold) continue ;
				
				// OK

				kmeans.addPoint(x, y);
			}
		}

		// Кластеризуем отклики
		
		kmeans.cluster();
		
		// Сохраняем обнаруженные объекты

		for (Cluster c : kmeans.clusters) {

			objects.add( new ColorObject(c.center, target, c.m) );
		}
	}
	
	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
				(sourceImage.getWidth(), sourceImage.getHeight(), sourceImage.getType());
		
		// Получаем графический контекст

		Graphics2D G = processedImage.createGraphics();

		// Размещаем исходное изображение

		G.drawImage(sourceImage, 0, 0, null);
		
		// Отображаем обнаруженные объекты
		
		new ColorObjectRender(objects).render(G);

		G.dispose();
	}
	
}

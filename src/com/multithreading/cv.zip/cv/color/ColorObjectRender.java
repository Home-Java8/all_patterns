/*
 * ColorObjectRender.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.color;

import common.ui.view.Render;

import geom.Point2D;

import java.awt.Graphics2D;

import java.util.ArrayList;

/**
 * Рендер объектов, характеризуемых цветом.
 * 
 * @author pavelvpster
 * 
 */
public final class ColorObjectRender implements Render {

	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 */
	public ColorObjectRender(ArrayList <ColorObject> objects) {
		
		this.objects = objects;
	}
	
	
	/**
	 * Объекты для рендеринга.
	 * 
	 */
	private final ArrayList <ColorObject> objects;
	

	@Override
	public void render(Graphics2D G) {
		
		for (ColorObject object : objects) drawColorObject(object, G);
	}
	
	
	/**
	 * Этот метод выполняет рендеринг указанного объекта.
	 * 
	 */
	public static void drawColorObject(ColorObject object, Graphics2D G) {
		
		// Цвет
		
		G.setColor(object.color.toJavaColor());
		
		// Крестик
		
		final Point2D p = object.location;
		
		G.drawLine(p.x - 5, p.y - 5, p.x + 5, p.y + 5);
		G.drawLine(p.x - 5, p.y + 5, p.x + 5, p.y - 5);
	}
	
}

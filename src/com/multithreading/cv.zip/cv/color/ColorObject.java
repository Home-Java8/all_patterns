/*
 * ColorObject.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.color;

import geom.Point2D;

import image.color.RGB;

/**
 * Объект, характеризуемый цветом.
 * 
 * @author pavelvpster
 * 
 */
public final class ColorObject {
	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param location положение объекта,
	 * 
	 * @param color цвет объекта,
	 * 
	 * @param n количество точек, образующих объект.
	 * 
	 */
	public ColorObject(Point2D location, RGB color, int n) {
		
		this.location = location; this.color = color; this.n = n;
	}
	
	
	/**
	 * Положение объекта.
	 * 
	 */
	public final Point2D location;
	
	/**
	 * Цвет объекта.
	 * 
	 */
	public final RGB color;
	
	/**
	 * Количество точек объекта.
	 * 
	 */
	public final int n;
	
}

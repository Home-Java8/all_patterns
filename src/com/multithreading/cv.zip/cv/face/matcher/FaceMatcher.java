/*
 * FaceMatcher.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.face.matcher;

import cv.face.detector.Face;

import math.Vector;

/**
 * Сопоставитель лиц.
 * 
 * @author pavelvpster
 * 
 */
public final class FaceMatcher {
	
	/**
	 * Этот метод возвращает "расстояние" между указанными лицами.
	 * 
	 * @param a лицо A,
	 * @param b лицо B.
	 * 
	 * @return double "расстояние".
	 * 
	 */
	public static double match(Face a, Face b) {
		
		final Vector traceA = new Vector(a.haarObject.trace);
		final Vector traceB = new Vector(b.haarObject.trace);
		
		return traceA.calculateDistanceTo(traceB);
	}
	
	/**
	 * Этот метод возвращает "расстояние" от указанного лица до указанной статистики нескольких лиц.
	 * 
	 * Применяется алгоритм рассчета расстояния с учетом веса элементов.
	 * 
	 * @param a лицо,
	 * @param b статистика нескольких лиц.
	 * 
	 * @return double "расстояние".
	 * 
	 */
	public static double match(Face a, FaceStatistics b) {

//		// Простой способ
//		
//		final Vector traceA = new Vector(a.haarObject.trace);
//		final Vector traceB = new Vector(b.mean);
//		
//		return traceA.calculateDistanceTo(traceB);

		
		// Расстояние до выборочного среднго с учетом дисперсии компонентов
		
		double d = 0.0;
		
		for (int i = 0; i < a.haarObject.trace.length; i ++) {
			
			final double di = a.haarObject.trace[i] - b.mean[i];
			
			// Вес частной разности обратно пропорционален вариации соответствующего компонента
			
			final double f = (1.0 / (1.0 + b.variance[i]));
			
			d += di * f * di * f;
		}
		
		d = Math.sqrt(d);
		
		return d;
	}
	
}

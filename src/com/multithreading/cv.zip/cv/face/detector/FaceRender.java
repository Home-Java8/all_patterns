/*
 * FaceRender.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.face.detector;

import common.ui.view.Render;

import cv.ui.RenderingParameters;

import geom.Rectangle;

import java.awt.Graphics2D;

import java.util.ArrayList;

/**
 * Рендер лиц.
 * 
 * @author pavelvpster
 * 
 */
public final class FaceRender implements Render {

	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param faces лица.
	 * 
	 */
	public FaceRender(ArrayList <Face> faces) {
		
		this.faces = faces;
	}

	
	/**
	 * Лица для рендеринга.
	 * 
	 */
	private final ArrayList <Face> faces;

	
	@Override
	public void render(Graphics2D G) {
		
		for (Face face : faces) drawFace(face, G);
	}
	
	
	/**
	 * Этот метод выполняет рендеринг указанного лица.
	 * 
	 */
	public static void drawFace(Face face, Graphics2D G) {
		
		// Цвет
		
		G.setColor(RenderingParameters.FACE_COLOR);
		
		// Тип линии
		
		G.setStroke(RenderingParameters.FACE_STROKE);

		// Прямоугольник
		
		final Rectangle r = face.haarObject.rectangle;
		
		G.drawRect(r.x, r.y, r.width, r.height);
		
		// Описание
		
		String t = String.format("Face: HaarScore = %.1f", face.haarObject.score);
		
		if (face.haarObject.trace != null) {
			
			t += " +Trace(" + face.haarObject.trace.length + ")";
		}
		
		G.drawString(t, r.x, r.y - 5);
	}
	
}

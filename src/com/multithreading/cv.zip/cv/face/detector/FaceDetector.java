/*
 * FaceDetector.java
 * 
 * Copyright (C) 2012-2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.face.detector;

import cv.haar.detector.HaarObject;

import cv.haar.detector.HaarObjectDetector;
import cv.haar.detector.HaarObjectDetectorParameters;

import image.AbstractImageProcessor;

import image.ImageProcessor;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

import java.util.ArrayList;

import org.apache.log4j.Logger;

/**
 * Детектор лиц.
 * 
 * На основе детектора объектов Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class FaceDetector extends AbstractImageProcessor {
	
	private static final Logger LOG = Logger.getLogger(FaceDetector.class);
	

	/**
	 * Конструктор по умолчанию.
	 * 
	 */
	public FaceDetector() {
		
		isLazy = true;
	}
	
	// Параметризованные конструкторы
	
	public FaceDetector(BufferedImage sourceImage) {
		
		isLazy = true;
		
		setSourceImage(sourceImage);
	}
	
	
	/**
	 * Непрозрачность рендеринга.
	 * 
	 * Если TRUE, рендеринг будет выполняться поверх исходного изображения;
	 * в противном случае поверх черного фона.
	 * 
	 */
	private boolean opaque = true;

	/**
	 * Этот метод возвращает непрозрачность рендеринга.
	 * 
	 * @return boolean
	 * 
	 */
	public boolean isOpaque() {
		
		return opaque;
	}
	
	/**
	 * Этот метод устанавливает непрозрачность рендеринга.
	 * 
	 * @param opaque непрозрачность.
	 * 
	 */
	public void setOpaque(boolean opaque) {
		
		this.opaque = opaque;
	}
	
	
	/**
	 * @see ImageProcessor
	 * 
	 */
	@Override
	public void setSourceImage(BufferedImage sourceImage) {
		
		// Передаем изображение детектору лиц

		haarDetector.setSourceImage(sourceImage);
	}
	
	/**
	 * @see ImageProcessor
	 * 
	 */
	@Override
	public BufferedImage getSourceImage() {
		
		return haarDetector.getSourceImage();
	}
	
	
	/**
	 * Детектор лиц.
	 * 
	 */
	private HaarObjectDetector haarDetector = 
					new HaarObjectDetector(HaarObjectDetectorParameters.createFaceDetectorParameters());
	
	
	/**
	 * Этот метод возвращает параметры детектора.
	 * 
	 * @return HaarObjectDetectorParameters
	 * 
	 */
	public HaarObjectDetectorParameters parameters() {
		
		return haarDetector.parameters();
	}
	
	
	/**
	 * Обнаруженные лица.
	 * 
	 */
	public ArrayList <Face> faces = new ArrayList <> ();
	
	
	/**
	 * Этот метод возвращает лицо обнаруженное с наибольшей достоверностью.
	 * 
	 * Под достоверностью понимаем оценку Хаара.
	 * 
	 * @return Face лицо.
	 * 
	 * Если лица не обнаружены, метод возвращает null.
	 * 
	 */
	public Face getMainFace() {
		
		Face r = null;
		
		double maxScore = 0;
		
		for (Face face : faces) {
			
			if (face.haarObject.score > maxScore) {
				
				maxScore = face.haarObject.score; r = face;
			}
		}
		
		return r;
	}

	
	/**
	 * @see ImageProcessor
	 * 
	 */
	@Override
	public void process() {
		
		LOG.debug("Detecting faces...");
		
		// Cleanup
		
		faces.clear();
		
		// Обнаруживаем лица
		
		haarDetector.process();
		
		for (HaarObject object : haarDetector.objects) {

			faces.add( new Face(object) );
		}
		
		LOG.debug("Done. " + faces.size() + " faces detected.");
	}
	
	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
			(getSourceImage().getWidth(), getSourceImage().getHeight(), getSourceImage().getType());
		
		// Получаем графический контекст

		Graphics2D G = processedImage.createGraphics();

		// Размещаем исходное изображение

		if (opaque) {
			
			G.drawImage(getSourceImage(), 0, 0, null);
		}
		
		// Отображаем обнаруженные лица
		
		new FaceRender(faces).render(G);

		G.dispose();
	}
	
}

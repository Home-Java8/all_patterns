/*
 * FaceDetectorHelper.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.face.detector;

import image.ImageHelper;

import java.awt.image.BufferedImage;

import org.apache.log4j.Logger;

/**
 * Этот класс содержит вспомогательные методы для обнаружения лиц.
 * 
 * @author pavelvpster
 * 
 */
public final class FaceDetectorHelper {
	
	private static final Logger LOG = Logger.getLogger(FaceDetectorHelper.class);
	
	
	/**
	 * Этот метод возвращает лицо, обнаруженное с наибольшей достоверностью на изображении.
	 * 
	 * @param faceImage изображение лица.
	 * 
	 * @return Face
	 * 
	 * Если лица не обнаружены, метод возвращает null.
	 * 
	 */
	public static Face getFaceFromImage(BufferedImage faceImage) {
		
		LOG.debug("Detecting face on image...");
		
		if (faceImage == null) {
			
			throw new RuntimeException("Face image undefined!");
		}
		
		FaceDetector faceDetector = new FaceDetector(faceImage);
		
		faceDetector.process();

		Face mainFace = faceDetector.getMainFace();
		
		LOG.debug("Done. " + (mainFace == null ? "Face not detected." : "Face detected (score = " + mainFace.haarObject.score + ")."));
		
		return mainFace;
	}
	
	/**
	 * Этот метод возвращает лицо, обнаруженное с наибольшей достоверностью на изображении из файла.
	 * 
	 * @param faceImageFilename имя файла изображения лица.
	 * 
	 * @return Face
	 * 
	 * Если лица не обнаружены, метод возвращает null.
	 * 
	 */
	public static Face getFaceFromImageFile(String faceImageFilename) {
		
		LOG.debug("Detecting face on image from file [" + faceImageFilename + "]...");
		
		BufferedImage faceImage = ImageHelper.loadImage(faceImageFilename);
		
		if (faceImage == null) {
			
			LOG.error("Error loading image [" + faceImageFilename + "]!");
			
			return null;
		}
		
		LOG.debug("Image loaded.");
		
		return getFaceFromImage(faceImage);
	}
	
}

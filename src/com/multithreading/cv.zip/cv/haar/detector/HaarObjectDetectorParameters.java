/*
 * HaarObjectDetectorParameters.java
 * 
 * Copyright (C) 2012-2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.haar.detector;

import cv.haar.cascade.HaarCascade;
import cv.haar.cascade.HaarCascadeHelper;

/**
 * Параметры детектора Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class HaarObjectDetectorParameters {
	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 */
	public HaarObjectDetectorParameters(String cascadeName) {
		
		this.cascadeName = cascadeName;
		
		cascade = HaarCascadeHelper.loadHaarCascade(this.cascadeName);
		
		if (cascade == null) {
			
			throw new RuntimeException();
		}
	}
	
	
	/**
	 * Имя каскада Хаара.
	 * 
	 */
	public final String cascadeName;

	/**
	 * Каскад Хаара.
	 * 
	 */
	public final HaarCascade cascade;
	
	/**
	 * Количество возможных положений объектов.
	 * 
	 */
	public int k = 16;

	/**
	 * Шаг по оси X.
	 *
	 */
//	public int xStep = 4;

	/**
	 * Шаг по оси Y.
	 *
	 */
//	public int yStep = 4;

	/**
	 * Минимальный масштаб.
	 * 
	 * Относительно размера каскада Хаара.
	 *
	 */
	public double minScale = 1.0;

	/**
	 * Максимальный масштаб.
	 *
	 * Относительно размера изображения.
	 * 
	 */
	public double maxScale = 0.8;

	/**
	 * Шаг уменьшения масштаба.
	 *
	 */
	public double scaleStep = 1.0;
	
	/**
	 * Порог количества откликов.
	 * 
	 */
	public int threshold = 8;
	
	/**
	 * Оптимизировать.
	 * 
	 */
	public boolean detectBiggest = true;

	/**
	 * Порог плозади пересечения объектов.
	 * 
	 */
	public double intersectionThreshold = 0.75;
	
	/**
	 * Сохранять отклик.
	 * 
	 */
	public boolean trace = false;
	
	
	//
	// Factory
	//
	
	
	/**
	 * Этот метод создает параметры для детектора лиц.
	 * 
	 * @return new HaarObjectDetectorParameters
	 * 
	 */
	public static HaarObjectDetectorParameters createFaceDetectorParameters() {
		
		HaarObjectDetectorParameters params = new HaarObjectDetectorParameters("data/NewHaarCascade_Face.xml");
		
		// Включаем трассировку
		
		params.trace = true;
		
		return params;
	}
	
	/**
	 * Этот метод создает параметры для детектора точек лица.
	 * 
	 * @return new HaarObjectDetectorParameters
	 * 
	 */
	public static HaarObjectDetectorParameters createFacePointsDetectorParameters(String pointName) {
		
		String cascadeName = null;
		
		switch (pointName) {
			
			case "L_Eye" : cascadeName = "data/NewHaarCascade_L_Eye.xml"; break;
			case "R_Eye" : cascadeName = "data/NewHaarCascade_R_Eye.xml"; break;
			case "Mouth" : cascadeName = "data/NewHaarCascade_Mouth.xml"; break;
		}
		
		if (cascadeName == null) {
			
			throw new RuntimeException("Unknown Face Point Name!");
		}
		
		HaarObjectDetectorParameters params = new HaarObjectDetectorParameters(cascadeName);
		
		// Поточнее чем обычно

		params.k = 1;
		
//		params.xStep = 1;
//		params.yStep = 1;
		
		return params;
	}
	
}

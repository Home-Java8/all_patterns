/*
 * HaarObjectRender.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.haar.detector;

import common.ui.view.Render;

import cv.ui.RenderingParameters;

import geom.Rectangle;

import java.awt.Graphics2D;

import java.util.ArrayList;

/**
 * Ренденр объектов, обнаруженных детектором Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class HaarObjectRender implements Render {
	
	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param objects объекты.
	 * 
	 */
	public HaarObjectRender(ArrayList <HaarObject> objects) {
		
		this.objects = objects;
	}
	
	
	/**
	 * Объекты для рендеринга.
	 * 
	 */
	private ArrayList <HaarObject> objects = new ArrayList <> ();
	

	@Override
	public void render(Graphics2D G) {
		
		for (HaarObject object : objects) drawHaarObject(object, G);
	}
	
	
	/**
	 * Этот метод выполняет рендеринг указанного объекта.
	 * 
	 */
	public static void drawHaarObject(HaarObject object, Graphics2D G) {
		
		// Цвет
		
		G.setColor(RenderingParameters.OBJECT_COLOR);
		
		// Тип линии
		
		G.setStroke(RenderingParameters.OBJECT_STROKE);

		// Прямоугольник
		
		final Rectangle r = object.rectangle;

		G.drawRect(r.x, r.y, r.width, r.height);
		
		// Описание
		
		String t = String.format("HaarScore = %.1f", object.score);
		
		if (object.trace != null) {
			
			t += " +Trace";
		}
		
		G.drawString(t, r.x, r.y - 5);
	}
	
}

/*
 * HaarObjectDetector.java
 * 
 * Copyright (C) 2012-2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.haar.detector;

import cv.haar.cascade.HaarCascadeEvaluator;

import cv.integral.IntegralImage;

import geom.Rectangle;

import image.AbstractImageProcessor;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

import java.util.ArrayList;

import ml.clustering.kmeans.Cluster;
import ml.clustering.kmeans.ClusterPoint;
import ml.clustering.kmeans.KMeansClusterer;

import org.apache.log4j.Logger;

/**
 * Детектор объектов Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class HaarObjectDetector extends AbstractImageProcessor {
	
	private static final Logger LOG = Logger.getLogger(HaarObjectDetector.class);
	

	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 */
	public HaarObjectDetector(HaarObjectDetectorParameters params) {
		
		isLazy = true;
		
		this.params = params;
		
		LOG.debug("Detector created.");
	}
	
	// Параметризованные конструкторы
	
	public HaarObjectDetector(HaarObjectDetectorParameters params, BufferedImage sourceImage) {
		
		isLazy = true;
		
		this.params = params;
		
		setSourceImage(sourceImage);
		
		LOG.debug("Detector created.");
	}
	
	
	/**
	 * Параметры детектора Хаара.
	 * 
	 */
	private final HaarObjectDetectorParameters params;


	/**
	 * Этот метод возвращает параметры детектора.
	 * 
	 * @return HaarObjectDetectorParameters
	 * 
	 */
	public HaarObjectDetectorParameters parameters() {
		
		return params;
	}
	
	
	/**
	 * Интегральное изображение.
	 * 
	 */
	public IntegralImage integralImage = null;
	

	/**
	 * @see IImageProcessor
	 * 
	 */
	@Override
	public void setSourceImage(BufferedImage sourceImage) {
		
		// Строим интегральное изображение
		
		integralImage = new IntegralImage(sourceImage);
		
		integralImage.process();
		
		// Обновляем ROI
		
		ROI = new Rectangle(0, 0, integralImage.width - 1, integralImage.height - 1);
		
		LOG.debug("Source image changed.");
	}
	
	/**
	 * @see IImageProcessor
	 * 
	 */
	@Override
	public BufferedImage getSourceImage() {
		
		return integralImage.getSourceImage();
	}
	
	
	/**
	 * Region of Interest.
	 * 
	 */
	public Rectangle ROI = null;
	
	
	/**
	 * Обнаруженные объекты.
	 * 
	 */
	public ArrayList <HaarObject> objects = new ArrayList <> ();
	
	
	/**
	 * Этот метод возвращает объект с наибольшим откликом Хаара.
	 * 
	 * @return HaarObject объект.
	 * 
	 * Если объекты не обнаружены, метод возвращает null.
	 * 
	 */
	public HaarObject getMainObject() {
		
		HaarObject r = null;
		
		double maxScore = 0.0;
		
		for (HaarObject object : objects) {
			
			if (object.score > maxScore) {
				
				maxScore = object.score; r = object;
			}
		}
		
		return r;
	}

	
	/**
	 * @see IImageProcessor
	 * 
	 */
	@Override
	public void process() {
		
		LOG.debug("Processing...");
		
		if (integralImage == null) {
			
			throw new RuntimeException("Integral image undefined!");
		}
		
		// Cleanup
		
		objects.clear();

		// Если ROI не определен, придется анализировать все изображение

		if (ROI == null) {
			
			ROI = new Rectangle(0, 0, integralImage.width - 1, integralImage.height - 1);
		}
		
		// Используется для оптимизации (alpha-pruning)
		
		double a = 0;
		
		// Обнаружение ведем от максимального масштаба к минимальному
		
		double scale = Math.min( ROI.width  / params.cascade.width, 
								 ROI.height / params.cascade.height ) * params.maxScale;

		do {
			
			final double r = detect(scale);
			
			if (params.detectBiggest) {
				
				// Pruning

				if (r > 0) {

					if (r > a) {

						a = r;

					} else break;
				}
			}
			
		} while ((scale -= params.scaleStep) >= params.minScale);
		
		if (params.detectBiggest) {

			// Сохраняем положение объекта с максимальным откликом

			ArrayList <HaarObject> t = new ArrayList <> ();
			
			HaarObject mainObject = getMainObject();
			
			if (mainObject != null) {

				LOG.debug("Main object has score = " + mainObject.score);

				t.add(mainObject);
			}
			
			objects = t;
			
		} else {
			
			// Группируем обнаруженные возможные положения объектов
			
			groupByIntersection();
		}
		
		// Если надо выполняем трассировку откликов
		
		if (params.trace) {
			
			for (HaarObject object : objects) {
				
				final Rectangle r = object.rectangle;
				
				object.trace = HaarCascadeEvaluator.traceHaarCascade(params.cascade, integralImage, 
																		r.x, r.y, r.width / params.cascade.width);
			}
		}
		
		LOG.debug("Done.");
	}


	/**
	 * Этот метод выполняет обнаружение объектов.
	 * 
	 * В результате получаем множество возможных положений объектов.
	 * 
	 * @return double наибольший наблюдаемый отклик.
	 * 
	 */
	private double detect(double scale) {
		
		LOG.debug("Detecting, scale = " + scale);
		
		// Определяем размер каскада Хаара
		
		final int cw = (int)( params.cascade.width  * scale );
		final int ch = (int)( params.cascade.height * scale );
		
		// Создаем кластеризатор
		
		KMeansClusterer kmeans = new KMeansClusterer(params.k);
		
		kmeans.threshold = params.threshold;
		
		// Шаг по осям будет зависеть от размера
		
		final int d = Math.max(1, (int)(scale / 4.0));
		
		// Haar Detection
		
		for (int y = ROI.getY1(); y < ROI.getY2() - ch; y += d /* params.yStep */ ) {
			
			for (int x = ROI.getX1(); x < ROI.getX2() - cw; x += d /* params.xStep */ ) {
				
				final double r = HaarCascadeEvaluator.evaluateHaarCascade(params.cascade, integralImage, x, y, scale);
				
				if (r > 0.0) {
					
					kmeans.addPoint(x + cw / 2, y + ch / 2);
				}
			}
		}
		
		// Кластеризуем отклики
		
		kmeans.cluster();
		
		// Группируем кластеры
		
		kmeans.group();
		
		// Сохраняем обнаруженные возможные положения объектов
		
		double maxScore = 0;
		
		for (Cluster c : kmeans.clusters) {
			
			// Объектом становится отклик который ближе других к центру кластера
			
			final ClusterPoint p = kmeans.getNearestPoint(c);
			
			// Создаем и сохраняем объект
			
			objects.add( new HaarObject( new Rectangle(p.point.x - cw / 2, p.point.y - ch / 2, cw, ch), c.m) );
			
			// Обновляем рекорд
			
			if (c.m > maxScore) {
				
				maxScore = c.m;
			}
		}
		
		LOG.debug("Found " + objects.size() + " candidates, maximum score = " + maxScore);
		
		return maxScore;
	}

	
	/**
	 * Этот метод группирует объекты по критерию пересечения их областей.
	 * 
	 */
	private void groupByIntersection() {

		LOG.debug("Group " + objects.size() + " candidates by rectangle intersection...");
		
		while (groupByIntersectionStep()) { }
		
		LOG.debug("Candidates grouped into " + objects.size() + " objects.");
	}

	/**
	 * Этот метод выполняет шаг группирования.
	 * 
	 * @return boolean TRUE, если объединение объектов произошло.
	 * 
	 */
	private boolean groupByIntersectionStep() {

		int i = 0;
		
		while (i < objects.size() - 1) {
			
			int j = i + 1;
			
			while (j < objects.size()) {

				// Есть два прямоугольника (объекта)
				
				Rectangle a = objects.get(i).rectangle;
				Rectangle b = objects.get(j).rectangle;
				
				// Проверяем, пересекаются ли они
				
				if (a.intersect(b)) {
					
					// Рассчитываем площадь пересечения
					
					final double s = a.intersection(b).getSquare();
					
					// Нас интересует относительная величина
					
					final double f = Math.max( a.getSquare() / s, b.getSquare() / s );
					
					// Проверяем порог
					
					if (f > params.intersectionThreshold) {
						
						// Выбираем победителя
						
						if (objects.get(i).score > objects.get(j).score) {
							
							// Победил A

							objects.remove(j);
							
						} else {
							
							// Победил B
							
							objects.remove(i);
						}
						
						return true;
					}
				}
				
				j ++ ;
			}
			
			i ++ ;
		}
		
		return false;
	}
	
	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
			(getSourceImage().getWidth(), getSourceImage().getHeight(), getSourceImage().getType());
		
		// Получаем графический контекст

		Graphics2D G = processedImage.createGraphics();

		// Размещаем исходное изображение

		G.drawImage(getSourceImage(), 0, 0, null);
		
		// Отображаем обнаруженные объекты
		
		new HaarObjectRender(objects).render(G);

		G.dispose();
	}
	
}

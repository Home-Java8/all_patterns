/*
 * HaarObject.java
 * 
 * Copyright (C) 2012-2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.haar.detector;

import geom.Rectangle;

import java.io.Serializable;

/**
 * Объект, обнаруженный детектором Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class HaarObject implements Serializable {
	
	private static final long serialVersionUID = 1L;
	

	/**
	 * Конструктор по умолчанию (параметризованный).
	 * 
	 * @param rectangle прямоугольник изображения, где объект был обнаружен,
	 * 
	 * @param score оценка Хаара.
	 * 
	 */
	public HaarObject(Rectangle rectangle, double score) {
		
		this.rectangle = rectangle; this.score = score;
	}

	
	/**
	 * Прямоугольник изображения, где объект был обнаружен.
	 * 
	 */
	public final Rectangle rectangle;
	
	/**
	 * Оценка Хаара.
	 * 
	 * Неотрицательное значение, чем больше тем лучше.
	 * 
	 */
	public final double score;
	
	/**
	 * Трассировка откликов каскада Хаара.
	 * 
	 * Используется для идентификации.
	 * 
	 */
	public double[] trace = null;

}

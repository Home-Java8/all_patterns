/*
 * HaarCascadeEvaluator.java
 * 
 * Copyright (C) 2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.haar.cascade;

import cv.integral.IntegralImage;

import java.util.ArrayList;

/**
 * Вспомогательный класс для вычисления отклика каскада Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class HaarCascadeEvaluator {
	
	private HaarCascadeEvaluator() { }
	
	
	/**
	 * Этот метод возвращает отклик каскада Хаара.
	 * 
	 * @param cascade каскад Хаара,
	 *
	 * @param integralImage интегральное изображение,
	 * 
	 * @param x координата X,
	 * @param y координата Y,
	 * 
	 * @param scale масштаб.
	 * 
	 * @return double отклик каскада Хаара.
	 * 
	 */
	public static double evaluateHaarCascade(HaarCascade cascade, IntegralImage integralImage, int x, int y, double scale) {

		return evaluateHaarCascade( createContext(cascade, integralImage, x, y, scale) );
	}
	
	/**
	 * Этот метод выполняет трассировку откликов каскада Хаара.
	 * 
	 * Под трассировкой понимается запись откликов фильтров последнего этапа каскада Хаара.
	 * 
	 * @param cascade каскад Хаара,
	 *
	 * @param integralImage интегральное изображение,
	 * 
	 * @param x координата X,
	 * @param y координата Y,
	 * 
	 * @param scale масштаб.
	 * 
	 * @return double[] массив откликов фильтров последнего этапа.
	 * 
	 */
	public static double[] traceHaarCascade(HaarCascade cascade, IntegralImage integralImage, int x, int y, double scale) {
		
		HaarContext context = createContext(cascade, integralImage, x, y, scale);
		
		// Создаем массив для хранения результатов трассировки
		
		context.trace = new ArrayList <> ();
		
		// Дальше все как обычно
		
		evaluateHaarCascade(context);
		
		// Преобразуем результат
		
		double[] r = new double [ context.trace.size() ];
		
		for (int i = 0; i < context.trace.size(); i ++) {
			
			r[i] = context.trace.get(i);
		}
		
		return r;
	}
	
	
	/**
	 * Этот метод создает и возвращает контекст Хаара.
	 * 
	 * @return new HaarContext.
	 * 
	 */
	public static HaarContext createContext(HaarCascade cascade, IntegralImage integralImage, int x, int y, double scale) {
		
		// Создаем контекст
		
		HaarContext context = new HaarContext();
		
		context.cascade = cascade;

		context.integralImage = integralImage;

		context.x = x;
		context.y = y;

		context.scale = scale;

		// Определяем размеры каскада
		
		int w = (int)(context.cascade.width  * context.scale);
		int h = (int)(context.cascade.height * context.scale);
		
		// Рассчитываем необходимые множители
		
		double f, a, b, c, d, m, s, v;
		
		// Factor
		
		f = 1.0 / (w * h);
		
		context.factor = f;
		
		// Sum
		
		a = context.integralImage.sum[x + w][y + h];
		b = context.integralImage.sum[x + w][y    ];
		c = context.integralImage.sum[x    ][y + h];
		d = context.integralImage.sum[x    ][y    ];

		m = (a - b - c + d) * f;
		
		// Square Sum
		
		a = context.integralImage.square[x + w][y + h];
		b = context.integralImage.square[x + w][y    ];
		c = context.integralImage.square[x    ][y + h];
		d = context.integralImage.square[x    ][y    ];

		s = (a - b - c + d) * f;
		
		// Variance
		
		v = s - (m * m);

		if (v >= 0.0) v = Math.sqrt(v); else v = 1.0;

		context.variance = v;

		return context;
	}

	/**
	 * Этот метод возвращает отклик каскада Хаара.
	 * 
	 * @param context контекст Хаара.
	 * 
	 * @return double оценка (количество успешно пройденных этапов).
	 *
	 */
	public static double evaluateHaarCascade(HaarContext context) {

		double s = 0.0;
		
		for (int i = 0; i < context.cascade.stages.length; i ++) {

			if (context.trace != null) {
				
				// Если мы на последнем этапе - включаем сохранение откликов

				if (i == context.cascade.stages.length - 1) {
				
					context.saveResponses = true;
				}
			}
			
			// Вычисляем отклик
			
			final double r = evaluateStage(context.cascade.stages[i], context);

			if (r == 0.0) return 0.0;

//			s += r;

			// Сумма откликов этапов неинформативна - полезнее знать сколько этапов прошло
			
			s += 1.0;
		}

		return s;
	}
	
	/**
	 * Этот метод возвращает отклик этапа каскада Хаара.
	 *
	 */
	private static double evaluateStage(HaarStage stage, HaarContext context) {

		double s = 0.0;

		for (HaarTree tree : stage.trees) {

			final double r = evaluateTree(tree, context);

			s += r;
		}

		if (s < stage.threshold) s = 0.0;

		return s;
	}

	/**
	 * Этот метод возвращает отклик дерева Хаара.
	 *
	 */
	private static double evaluateTree(HaarTree tree, HaarContext context) {

		double s = 0.0;

		int index = 0;

		do {

			HaarTreeNode node = tree.nodes[index];

			final double r = evaluateTreeNode(node, context);

			if (r < node.threshold * context.variance) {

				index = node.left;

				if (index == -1) {

					s = node.alpha[0];
				}

			} else {

				index = node.right;

				if (index == -1) {

					s = node.alpha[1];
				}
			}

		} while (index > 0);

		return s;
	}

	/**
	 * Этот метод возвращает отклик элемента дерева Хаара.
	 * 
	 * @param context контекст Хаара.
	 *
	 */
	private static double evaluateTreeNode(HaarTreeNode node, HaarContext context) {

		final double r = evaluateFeature(node.feature, context.integralImage, context.x, context.y, context.scale, context.factor);
		
		// Если надо, сохраняем отклик
		
		if (context.saveResponses) {
			
			context.trace.add(r);
		}
		
		return r;
	}

	/**
	 * Этот метод возвращает отклик фильтра Хаара.
	 *
	 */
	private static double evaluateFeature(HaarFeature feature, IntegralImage integralImage, int x, int y, double scale, double factor) {

		double s = 0;

		for (HaarFeatureRect rect : feature.rects) {

			final int u = (int)(rect.x * scale) + x;
			final int v = (int)(rect.y * scale) + y;
			
			final int w = (int)(rect.width  * scale);
			final int h = (int)(rect.height * scale);

			if (!feature.rotated) {

				double a = integralImage.sum[u + w][v + h];
				double b = integralImage.sum[u + w][v    ];
				double c = integralImage.sum[u    ][v + h];
				double d = integralImage.sum[u    ][v    ];

				s += (a - b - c + d) * rect.weight * factor;
				
			} else {

				double a = integralImage.rotated[u + w    ][v + w    ];
				double b = integralImage.rotated[u - h    ][v + h    ];
				double c = integralImage.rotated[u + w - h][v + w + h];
				double d = integralImage.rotated[u        ][v        ];

				s += (a + b - c - d) * rect.weight * factor;
			}
		}

		return s;
	}

}

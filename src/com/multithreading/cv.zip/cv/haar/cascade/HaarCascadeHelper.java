/*
 * HaarCascadeHelper.java
 * 
 * Copyright (C) 2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.haar.cascade;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

/**
 * Вспомогательный класс для чтения и записи каскада Хаара.
 * 
 * @author pavelvpster
 * 
 */
public final class HaarCascadeHelper {
	
	private static final Logger LOG = Logger.getLogger(HaarCascadeHelper.class);
	
	
	private HaarCascadeHelper() { }
	
	
	/**
	 * Этот метод читает каскад Хаара.
	 * 
	 * @param filename имя файла.
	 * 
	 * @return HaarCascade
	 * 
	 */
	public static HaarCascade loadHaarCascade(String filename) {

		LOG.debug("Loading Haar cascade...");
		
		HaarCascade r = null;
		
		try {
			
			JAXBContext context = JAXBContext.newInstance(HaarCascade.class);
			
			Unmarshaller unmarshaller = context.createUnmarshaller();
			
			r = (HaarCascade)unmarshaller.unmarshal(new FileInputStream(filename));
			
		} catch (JAXBException | FileNotFoundException E) {
			
			LOG.error(E);
		}
		
		LOG.debug("Done.");
		
		return r;
	}

	/**
	 * Этот метод сохраняет каскад Хаара.
	 * 
	 * @param cascade каскад,
	 * 
	 * @param filename имя файла.
	 * 
	 */
	public static void saveHaarCascade(HaarCascade cascade, String filename) {

		LOG.debug("Saving Haar cascade...");
		
		try {
			
			JAXBContext context = JAXBContext.newInstance(HaarCascade.class);
			
			Marshaller marshaller = context.createMarshaller();
			
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshaller.marshal(cascade, new FileOutputStream(filename));
			
		} catch (JAXBException | FileNotFoundException E) {
			
			LOG.error(E);
		}
		
		LOG.debug("Done.");
	}
	
}

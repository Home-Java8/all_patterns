/*
 * HaarCascadeLoader.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package com.multithreading.cv.haar.cascade;

import java.io.IOException;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.xml.sax.SAXException;

/**
 * Загрузчик каскада Хаара.
 *
 * @author pavelvpster
 * 
 */
@Deprecated
public final class HaarCascadeLoader {

	/**
	 * Этот метод читает каскад Хаара.
	 * 
	 */
	public static HaarCascade loadHaarCascade(String filename) {

		// Создаем фабрику строителей документов

		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

		// Будем игнорировать лишние пробелы

		documentBuilderFactory.setIgnoringElementContentWhitespace(true);

		// Создаем строитель документов

		DocumentBuilder documentBuilder;

		try {

			documentBuilder = documentBuilderFactory.newDocumentBuilder();

		} catch (ParserConfigurationException E) {

			return null;
		}

		// Читаем документ

		Document xmlDocument;

		try {

			xmlDocument = documentBuilder.parse(filename);

		} catch (SAXException | IOException E) {

			return null;
		}

		// Получаем HaarCascade

		Element xmlCascadeNode = xmlDocument.getDocumentElement();

		// Проверяем имя

		if (!xmlCascadeNode.getNodeName().equals("haar-cascade")) {

			return null;
		}

		// Читаем каскад Хаара

		HaarCascade cascade = parseHaarCascade(xmlCascadeNode);
		
		return cascade;
	}

	/**
	 * Этот метод парсит HaarCascade.
	 *
	 */
	private static HaarCascade parseHaarCascade(Element xmlHaarCascade) {

		HaarCascade cascade = new HaarCascade();

		Node xmlCascadeNode = xmlHaarCascade.getFirstChild();

		while (xmlCascadeNode != null) {
			
			switch (xmlCascadeNode.getNodeName()) {
				
				case "width":
					
					cascade.width = Integer.parseInt(xmlCascadeNode.getTextContent());
					
					break;
					
					
				case "height":
					
					cascade.height = Integer.parseInt(xmlCascadeNode.getTextContent());
					
					break;
					
					
				case "stages":
					
					ArrayList <HaarStage> stages = new ArrayList <> ();

					Node xmlStage = xmlCascadeNode.getFirstChild();

					while (xmlStage != null) {
						
						switch (xmlStage.getNodeName()) {
						
							case "haar-stage":
								
								stages.add( parseHaarStage(xmlStage) );
								
								break;
						}

						xmlStage = xmlStage.getNextSibling();
					}

					cascade.stages = stages.toArray(new HaarStage[0]);
					
					break;
			}

			xmlCascadeNode = xmlCascadeNode.getNextSibling();
		}

		return cascade;
	}

	/**
	 * Этот метод парсит HaarStage.
	 *
	 */
	private static HaarStage parseHaarStage(Node xmlHaarStage) {

		HaarStage stage = new HaarStage();

		Node xmlStageNode = xmlHaarStage.getFirstChild();

		while (xmlStageNode != null) {

			switch (xmlStageNode.getNodeName()) {
				
				case "trees":
					
					ArrayList <HaarTree> trees = new ArrayList <> ();

					Node xmlTree = xmlStageNode.getFirstChild();

					while (xmlTree != null) {

						switch (xmlTree.getNodeName()) {

							case "haar-tree":

								trees.add( parseHaarTree(xmlTree) );

								break;
						}

						xmlTree = xmlTree.getNextSibling();
					}

					stage.trees = trees.toArray(new HaarTree[0]);
					
					break;
					
					
				case "threshold":
					
					stage.threshold = Double.parseDouble(xmlStageNode.getTextContent());
					
					break;
			}
			
			xmlStageNode = xmlStageNode.getNextSibling();
		}

		return stage;
	}

	/**
	 * Этот метод парсит HaarTree.
	 *
	 */
	private static HaarTree parseHaarTree(Node xmlHaarTree) {

		HaarTree tree = new HaarTree();

		Node xmlTreeNode = xmlHaarTree.getFirstChild();

		while (xmlTreeNode != null) {

			switch (xmlTreeNode.getNodeName()) {
				
				case "nodes":

					ArrayList <HaarTreeNode> nodes = new ArrayList <> ();

					Node xmlNode = xmlTreeNode.getFirstChild();

					while (xmlNode != null) {

						switch (xmlNode.getNodeName()) {

							case "haar-tree-node":

								nodes.add( parseHaarTreeNode(xmlNode) );

								break;
						}

						xmlNode = xmlNode.getNextSibling();
					}

					tree.nodes = nodes.toArray(new HaarTreeNode[0]);
					
					break;
			}

			xmlTreeNode = xmlTreeNode.getNextSibling();
		}

		return tree;
	}

	/**
	 * Этот метод парсит HaarTreeNode.
	 *
	 */
	private static HaarTreeNode parseHaarTreeNode(Node xmlHaarTreeNode) {

		HaarTreeNode node = new HaarTreeNode();

		Node xmlTreeNodeNode = xmlHaarTreeNode.getFirstChild();

		while (xmlTreeNodeNode != null) {
			
			switch (xmlTreeNodeNode.getNodeName()) {
				
				case "haar-feature":
					
					node.feature = parseHaarFeature(xmlTreeNodeNode);
					
					break;
					
					
				case "threshold":
					
					node.threshold = Double.parseDouble(xmlTreeNodeNode.getTextContent());
					
					break;
					
					
				case "left-alpha":
					
					node.alpha[0] = Double.parseDouble(xmlTreeNodeNode.getTextContent());
					
					break;
					
					
				case "right-alpha":
					
					node.alpha[1] = Double.parseDouble(xmlTreeNodeNode.getTextContent());
					
					break;
			}

			xmlTreeNodeNode = xmlTreeNodeNode.getNextSibling();
		}

		return node;
	}

	/**
	 * Этот метод парсит HaarFeature.
	 *
	 */
	private static HaarFeature parseHaarFeature(Node xmlHaarFeature) {

		HaarFeature feature = new HaarFeature();

		Node xmlFeatureNode = xmlHaarFeature.getFirstChild();

		while (xmlFeatureNode != null) {

			switch (xmlFeatureNode.getNodeName()) {
				
				case "rotated":
					
					feature.rotated = Integer.parseInt(xmlFeatureNode.getTextContent()) == 1;
					
					break;
					
					
				case "rects":
					
					ArrayList <HaarFeatureRect> rects = new ArrayList <> ();

					Node xmlRect = xmlFeatureNode.getFirstChild();

					while (xmlRect != null) {

						switch (xmlRect.getNodeName()) {

							case "haar-feature-rect":

								rects.add( parseHaarFeatureRect(xmlRect) );

								break;
						}

						xmlRect = xmlRect.getNextSibling();
					}

					feature.rects = rects.toArray(new HaarFeatureRect[0]);
					
					break;
			}

			xmlFeatureNode = xmlFeatureNode.getNextSibling();
		}

		return feature;
	}

	/**
	 * Этот метод парсит HaarFeatureRect.
	 *
	 */
	private static HaarFeatureRect parseHaarFeatureRect(Node xmlHaarFeatureRect) {

		HaarFeatureRect rect = new HaarFeatureRect();

		Node xmlRectNode = xmlHaarFeatureRect.getFirstChild();
		
		while (xmlRectNode != null) {

			switch (xmlRectNode.getNodeName()) {

				case "x":

					rect.x = Integer.parseInt(xmlRectNode.getTextContent());

					break;


				case "y":

					rect.y = Integer.parseInt(xmlRectNode.getTextContent());

					break;


				case "width":

					rect.width = Integer.parseInt(xmlRectNode.getTextContent());

					break;


				case "height":

					rect.height = Integer.parseInt(xmlRectNode.getTextContent());

					break;


				case "weight":

					rect.weight = Double.parseDouble(xmlRectNode.getTextContent());

					break;
			}
			
			xmlRectNode = xmlRectNode.getNextSibling();
		}

		return rect;
	}

}

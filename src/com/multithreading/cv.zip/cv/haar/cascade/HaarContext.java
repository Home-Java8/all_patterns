/*
 * HaarContext.java
 *
 * Copyright (C) 2012-2014  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

package com.multithreading.cv.haar.cascade;

import cv.integral.IntegralImage;

import java.util.ArrayList;

/**
 * Контекст Хаара.
 * 
 * Используется для хранения параметров при прохождении по каскаду.
 *
 * @author pavelvpster
 *
 */
public final class HaarContext {
	
	/**
	 * Каскад Хаара.
	 * 
	 */
	public HaarCascade cascade = null;
	
	/**
	 * Интегральное изображение.
	 * 
	 */
	public IntegralImage integralImage = null;

	/**
	 * Координата X.
	 * 
	 */
	public int x = 0;

	/**
	 * Координата Y.
	 *
	 */
	public int y = 0;

	/**
	 * Масштаб.
	 * 
	 */
	public double scale = 1.0;
	
	/**
	 * Множитель результата.
	 *
	 * Обратно пропорционален площади и служит для нормирования откликов.
	 * 
	 */
	public double factor = 1.0;

	/**
	 * Множитель порога.
	 *
	 * Пропорционален вариации интенсивности и служит для адаптации порогов.
	 * 
	 */
	public double variance = 1.0;

	/**
	 * Результаты трассировки.
	 * 
	 */
	public ArrayList <Double> trace = null;
	
	/**
	 * Если TRUE, отклики фильтров Хаара будут сохраняться.
	 * 
	 */
	public boolean saveResponses = false;
	
}

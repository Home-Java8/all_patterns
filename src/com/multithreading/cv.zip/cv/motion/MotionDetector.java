/*
 * MotionDetector.java
 * 
 * Copyright (C) 2012  Pavel Prokhorov (pavelvpster@gmail.com)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package com.multithreading.cv.motion;

import cv.ui.RenderingParameters;

import image.AbstractImageProcessor;

import image.ImageProcessor;

import image.color.RGB;

import image.processing.Grayscale;

import java.awt.image.BufferedImage;

/**
 * Детектор движения.
 * 
 * Простой алгоритм: проверяется отклонение интенсивности точек от среднего значения интенсивности.
 * 
 * @author pavelvpster
 * 
 */
public class MotionDetector extends AbstractImageProcessor {

	/**
	 * Конструктор по умолчанию.
	 * 
	 */
	public MotionDetector() {
		
		isLazy = true;
	}
	
	// Параметризованные конструкторы
	
	public MotionDetector(BufferedImage sourceImage) {
		
		super(sourceImage);
		
		isLazy = true;
	}
	
	public MotionDetector(BufferedImage sourceImage, int n) {
		
		super(sourceImage);
		
		isLazy = true;
		
		this.n = n;
	}
	
	public MotionDetector(int n) {
		
		isLazy = true;
		
		this.n = n;
	}
	
	
	/**
	 * Количество кадров для усреднения.
	 * 
	 */
	public int n = 5;
	
	/**
	 * Ширина изображения.
	 *
	 */
	public int width = 0;

	/**
	 * Высота изображения.
	 *
	 */
	public int height = 0;

	
	/**
	 * Средние значения интенсивностей точек.
	 * 
	 */
	private double[][] mean = null;
	
	
	/**
	 * Обнаруженное движение.
	 * 
	 */
	public boolean[][] motion = null;
	

	/**
	 * @see ImageProcessor
	 * 
	 */
	@Override
	public void process() {
		
		if (sourceImage == null) {
			
			throw new RuntimeException("Source image undefined!");
		}
		
		// Нам понадобятся интенсивности точек
		
		Grayscale grayscale = new Grayscale(sourceImage);

		grayscale.process();

		BufferedImage intensityImage = grayscale.getProcessedImage();

		// Motion detection
		
		if (mean == null) {
			
			// Сохраняем размеры изображения
			
			width  = intensityImage.getWidth ();
			height = intensityImage.getHeight();
			
			// Инициализируем средние значения
			
			mean = new double[width][height];
			
			for (int y = 0; y < height; y ++) {
				
				for (int x = 0; x < width; x ++) {
					
					int i = RGB.get(intensityImage, x, y).I;
					
					mean[x][y] = (double)i;
				}
			}
			
			// Инициализируем движение
			
			motion = new boolean[width][height];
			
		} else {

			// Рассчитываем коэффициент усреднения
			
			final double a = 2.0 / ((double)n + 1.0);
			
			// Обновляем модель
			
			for (int y = 0; y < height; y ++) {
				
				for (int x = 0; x < width; x ++) {
					
					int i = RGB.get(intensityImage, x, y).I;
					
					// Обновляем выборочное среднее
					
					mean[x][y] = (1.0 - a) * mean[x][y] + a * (double)i;

					// Рассчитываем разницу интенсивностей
					
					final double d = Math.abs((double)i - mean[x][y]);
					
					// Проверяем порог
					
					motion[x][y] = d > 25.0;
				}
			}
		}
	}

	
	/**
	 * @see AbstractImageProcessor
	 * 
	 */
	@Override
	public void render() {
		
		// Создаем обработанное изображение
		
		processedImage = new BufferedImage
			(sourceImage.getWidth(), sourceImage.getHeight(), sourceImage.getType());
		
		// Отображаем обнаруженное движение

		RGB a = new RGB(RenderingParameters.MOTION_COLOR);
		
		for (int y = 0; y < height; y ++) {
			
			for (int x = 0; x < width; x ++) {
				
				if (motion[x][y]) {
					
					a.set(processedImage, x, y);
				}
			}
		}
	}
	
}
